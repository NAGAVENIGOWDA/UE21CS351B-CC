
class NotALeaderException(Exception):
    pass
